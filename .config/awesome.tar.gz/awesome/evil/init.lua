require("evil.battery")
require("evil.volume")
require("evil.brightness")