local apps = {
    terminal = "alacritty", 
    launcher = "rofi -modi drun -show drun", 
    switcher = require("widgets.alt-tab"), 
    xrandr = "lxrandr", 
    screenshot = "scrot -e 'echo $f'", 
    volume = "pavucontrol", 
    appearance = "lxappearance", 
    browser = "firefox", 
    fileexplorer = "thunar",
    musicplayer = "mpv", 
    settings = "code /home/parndt/awesome/"
}

user = {
    terminal = "alacritty", 
    floating_terminal = "alacritty"
}

return apps
